package org.psp.servidor;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Punto de entrada del ejecutable del servidor
 * @author Rubén
 */
public class Inicio {

    /**
     * @param args en args[0] ha de estar el número de puerto
     */
    public static void main(String[] args) {

        Servidor servidor = new Servidor(Integer.parseInt(args[0]));
        try {
            //arrancamos el servidor
            servidor.escuchar();
        } catch (IOException ex) {
            Logger.getLogger(Inicio.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
