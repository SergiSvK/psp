package org.psp.servidor;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Proceso servidor
 *
 * @author Rubén
 */
public class Servidor {

    private int puerto;
    private int numCliente;

    public Servidor(int puerto) {
        this.puerto = puerto;
        this.numCliente = 0;
    }

    public void escuchar() throws IOException {

        ServerSocket server = new ServerSocket(puerto);

        while (true) {
            try {
                System.out.println("Esperando peticiones en el puerto " + puerto + "...");
                Socket socketCliente = server.accept();

                //llega un cliente, creamos un nuevo thread para atender al cliente
                numCliente++;
                System.out.println("Nueva conexión de cliente recibida. Cliente " + numCliente);
                HiloCliente suministrador = new HiloCliente(numCliente,socketCliente);
                suministrador.start();
                
            } catch (IOException ex) {
                Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
