package org.psp.servidor;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.psp.comunes.Ciudad;

/**
 * Implementa el tratamiento a una petición de un cliente en su propio hilo
 *
 * @author Rubén
 */
public class HiloCliente extends Thread {

    private static final String FICHERO = "temperaturas.txt";
    private static final String END_OF_SESSION = "-1";
    private int numCliente;
    private Socket socket;

    public HiloCliente(int numCliente, Socket socket) {
        this.numCliente = numCliente;
        this.socket = socket;
    }

    @Override
    public void start() {

        try {
            //crear los streams de entrada y salida
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());

            String codigoCiudad = "-1";
            do {
                try {
                    //obtener el código de la ciudad   
                    codigoCiudad = in.readLine();
                    mostrarEventoLog("Nueva petición para ciudad " + codigoCiudad);

                    //recuperar las temperaturas
                    ArrayList<String> temperaturas = recuperarTemperaturas(codigoCiudad);
                    //responder al cliente
                    Ciudad ciudad = new Ciudad(codigoCiudad,"");
                    ciudad.setTemperaturas(temperaturas);

                    out.writeObject(ciudad);
                    out.flush();
                } catch (IOException ex) {
                    Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
                    mostrarEventoLog("Error: " + ex);
                }

            } while (!codigoCiudad.equals(END_OF_SESSION));
            //cerrar los streams y el socket
            in.close();
            out.close();
            socket.close();
            mostrarEventoLog("Fin de sesión. Cliente desconectado");

        } catch (IOException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
            mostrarEventoLog("Error: " + ex);
        }

    }

    /**
     * Mostrar un nuevo mensaje para este hilo de cliente en el log
     *
     * @param mensaje mensaje a mostrar
     */
    private void mostrarEventoLog(String mensaje) {
        System.out.println("Cliente " + numCliente + " : " + mensaje);
    }

    /**
     * Recupera las temperaturas de la ciudad del fichero en disco
     *
     * @param codigoCiudad
     * @return
     * @throws IOException
     */
    private ArrayList<String> recuperarTemperaturas(String codigoCiudad) throws IOException {

        FileReader fichero = new FileReader(FICHERO);
        BufferedReader buffer = null;
        ArrayList<String> temperaturas = new ArrayList<String>();
        try {
            buffer = new BufferedReader(fichero);
            String linea;
            //procesamos cada línea
            while ((linea = buffer.readLine()) != null) {
                String[] tokens = linea.split(";");
                for (String token : tokens) {
                    String[] lectura = token.split(",");
                    if (lectura.length == 2 && lectura[0].equals(codigoCiudad)) {
                        temperaturas.add(lectura[1]);
                    }
                }

            }
        } catch (IOException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            buffer.close();
            fichero.close();
            return temperaturas;
        }
    }

}
